import React, { useState, useEffect, useCallback, useMemo } from "react";
import { ethers } from "ethers";
import {
  getContract,
  loadTerms,
  fetchHolders,
  hasFn,
  BOND_DECIMALS,
  USDC_DECIMALS,
  txUrl,
} from "../contracts/platform";
import { toUnits, fromUnits, fmtNumber, shortAddr, friendlyError } from "../lib/utils";
import { useAuth } from "../context/AuthContext";
import { useToast } from "./Toast";
import {
  DollarSign,
  Calendar,
  Users,
  Coins,
  CheckCircle2,
  Clock,
  RefreshCw,
  AlertTriangle,
  Layers,
  ArrowRight,
  ShieldCheck,
  TrendingUp,
  FileCheck,
} from "lucide-react";
import TestUsdcFaucetModal from "./TestUsdcFaucetModal";

export default function AdminCouponTerminal() {
  const { account, signer, readProvider, network, roles, refreshTrigger, setRefreshTrigger } = useAuth();
  const toast = useToast();

  const [terms, setTerms] = useState(null);
  const [selectedPeriod, setSelectedPeriod] = useState("1");
  const [activePeriods, setActivePeriods] = useState([1]);
  const [couponPoolBalance, setCouponPoolBalance] = useState(0n);
  const [usdcBalance, setUsdcBalance] = useState(0n);
  const [holders, setHolders] = useState([]);
  const [loading, setLoading] = useState(false);

  // Fund Pool Form
  const [fundAmount, setFundAmount] = useState("");
  const [fundingBusy, setFundingBusy] = useState(false);
  const [fundingStep, setFundingStep] = useState("");

  // Snapshot Recording
  const [snapshotBusy, setSnapshotBusy] = useState(false);
  const [snapshotStep, setSnapshotStep] = useState("");
  const [faucetOpen, setFaucetOpen] = useState(false);

  // Load contract state
  const loadAdminData = useCallback(async () => {
    if (!readProvider) return;
    setLoading(true);
    try {
      const t = await loadTerms(readProvider, network);
      setTerms(t);

      const bond = getContract("BondToken", readProvider, network);
      const usdc = getContract("MockUSDC", readProvider, network);
      const dist = getContract("CouponDistributor", readProvider, network);
      const distAddr = await dist.getAddress();

      // Pool balance & admin balances
      const [poolBal, uBal] = await Promise.all([
        usdc.balanceOf(distAddr),
        account ? usdc.balanceOf(account) : 0n,
      ]);
      setCouponPoolBalance(poolBal);
      setUsdcBalance(uBal);

      // Active periods
      try {
        if (hasFn(dist, "getActivePeriods")) {
          const raw = await dist.getActivePeriods();
          const list = raw.map((p) => Number(p));
          if (list.length > 0) setActivePeriods(list);
        }
      } catch {}

      // Discover token holders using events & common accounts
      let discoveredHolders = [];
      try {
        const hList = await fetchHolders(bond, readProvider, network);
        discoveredHolders = hList;
      } catch {
        discoveredHolders = account ? [{ address: account, balance: await bond.balanceOf(account) }] : [];
      }

      // Check on-chain snapshot and claim status for each holder in selectedPeriod
      const periodId = BigInt(selectedPeriod);
      const holderStatusList = await Promise.all(
        discoveredHolders.map(async (h) => {
          let snapBal = 0n;
          let hasClaimed = false;
          let calculatedCoupon = 0n;

          try {
            [snapBal, hasClaimed, calculatedCoupon] = await Promise.all([
              dist.snapshotBalances(periodId, h.address),
              dist.hasClaimed(periodId, h.address),
              dist.calculateCoupon(h.balance),
            ]);
          } catch {}

          return {
            ...h,
            snapBal,
            hasClaimed,
            calculatedCoupon,
          };
        })
      );

      setHolders(holderStatusList);
    } catch (err) {
      console.warn("Could not load admin coupon terminal data:", err);
    } finally {
      setLoading(false);
    }
  }, [account, readProvider, network, selectedPeriod]);

  useEffect(() => {
    loadAdminData();
  }, [loadAdminData, refreshTrigger]);

  // Calculate total coupon liability for eligible holders
  const totalLiability = useMemo(() => {
    return holders.reduce((sum, h) => sum + h.calculatedCoupon, 0n);
  }, [holders]);

  const totalLiabilityFormatted = fmtNumber(fromUnits(totalLiability, USDC_DECIMALS));
  const poolBalanceFormatted = fmtNumber(fromUnits(couponPoolBalance, USDC_DECIMALS));
  const isFullyFunded = couponPoolBalance >= totalLiability;

  // 1. FUND COUPON POOL
  const handleFundCouponPool = async (e) => {
    e.preventDefault();
    if (!signer) return toast.warn("Connect your authorized issuer/admin wallet.");
    const numAmt = Number(fundAmount);
    if (!numAmt || numAmt <= 0) return toast.warn("Enter a valid deposit amount.");

    setFundingBusy(true);
    try {
      const usdc = getContract("MockUSDC", signer, network);
      const dist = getContract("CouponDistributor", signer, network);
      const distAddr = await dist.getAddress();
      const rawAmt = toUnits(String(numAmt), USDC_DECIMALS);

      // Check allowance
      setFundingStep("Checking USDC approval in MetaMask...");
      const allowance = await usdc.allowance(account, distAddr);

      if (allowance < rawAmt) {
        setFundingStep("Confirming USDC approval in MetaMask...");
        const appTx = await usdc.approve(distAddr, rawAmt);
        await appTx.wait();
      }

      // Deposit
      setFundingStep(`Depositing $${fmtNumber(numAmt)} USDC to Coupon Pool in MetaMask...`);
      const depositTx = await dist.depositCouponFunds(rawAmt);
      setFundingStep("Confirming transaction on Sepolia...");
      await depositTx.wait();

      toast.success(`Successfully funded $${fmtNumber(numAmt)} USDC into the Coupon Pool!`);
      setFundAmount("");
      setRefreshTrigger((n) => n + 1);
      loadAdminData();
    } catch (err) {
      console.error("Fund pool error:", err);
      toast.error(friendlyError(err));
    } finally {
      setFundingBusy(false);
      setFundingStep("");
    }
  };

  // 2. RECORD ELIGIBLE INVESTOR SNAPSHOT
  const handleRecordSnapshot = async () => {
    if (!signer) return toast.warn("Connect authorized issuer/admin wallet.");
    if (holders.length === 0) return toast.warn("No eligible tokenholders found to record.");

    setSnapshotBusy(true);
    try {
      const dist = getContract("CouponDistributor", signer, network);
      const periodId = BigInt(selectedPeriod);
      const addresses = holders.map((h) => h.address);
      const balances = holders.map((h) => h.balance);

      setSnapshotStep(`Recording Period ${selectedPeriod} snapshot for ${addresses.length} holders in MetaMask...`);
      const tx = await dist.recordSnapshot(periodId, addresses, balances);
      setSnapshotStep("Confirming snapshot on Sepolia testnet...");
      await tx.wait();

      toast.success(`Snapshot for Period ${selectedPeriod} recorded on-chain! Investors can now claim.`);
      setRefreshTrigger((n) => n + 1);
      loadAdminData();
    } catch (err) {
      console.error("Record snapshot error:", err);
      toast.error(friendlyError(err));
    } finally {
      setSnapshotBusy(false);
      setSnapshotStep("");
    }
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "1.75rem", maxWidth: 1200, margin: "0 auto" }}>
      {/* Header Banner */}
      <div className="card">
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: "1rem" }}>
          <div>
            <div style={{ display: "flex", gap: "0.5rem", alignItems: "center" }}>
              <span className="badge badge-blue">ADMINISTRATION</span>
              <span className="badge badge-emerald">Coupon Operations</span>
            </div>
            <h2 style={{ fontSize: "1.6rem", fontWeight: 800, marginTop: "0.35rem" }}>
              Coupon Distribution Terminal
            </h2>
            <p style={{ color: "var(--text-secondary)", fontSize: "0.85rem", marginTop: "0.25rem", maxWidth: 650 }}>
              Audit eligible bondholder balances, calculate total interest liabilities, deposit USDC liquidity, and
              commit cryptographic investor snapshots to `CouponDistributor.sol`.
            </p>
          </div>

          <div style={{ display: "flex", gap: "0.5rem", flexWrap: "wrap", alignItems: "center" }}>
            <button
              className="btn btn-emerald btn-sm"
              onClick={() => setFaucetOpen(true)}
              title="Mint test MockUSDC for funding"
            >
              <Coins size={13} />
              <span>Get Test USDC</span>
            </button>

            <button
              className="btn-icon"
              onClick={() => { setRefreshTrigger((n) => n + 1); loadAdminData(); }}
              aria-label="Refresh admin data"
              title="Refresh"
            >
              <RefreshCw size={13} className={loading ? "animate-spin" : ""} />
            </button>
          </div>
        </div>

        {/* 4 Operations KPI Cards */}
        <div className="grid-4" style={{ marginTop: "1.5rem" }}>
          <div className="stat-box">
            <div className="stat-label">Active Coupon Pool</div>
            <div className="stat-value font-mono" style={{ color: "var(--accent-emerald)" }}>
              ${poolBalanceFormatted}
            </div>
            <div className="stat-sub">Held in smart contract</div>
          </div>

          <div className="stat-box">
            <div className="stat-label">Period {selectedPeriod} Liability</div>
            <div className="stat-value font-mono" style={{ color: "var(--accent-blue)" }}>
              ${totalLiabilityFormatted}
            </div>
            <div className="stat-sub">Across {holders.length} eligible holders</div>
          </div>

          <div className="stat-box">
            <div className="stat-label">Funding Status</div>
            <div className="stat-value" style={{ fontSize: "1.1rem", marginTop: 4 }}>
              {isFullyFunded ? (
                <span className="badge badge-emerald">Fully Funded (100%)</span>
              ) : (
                <span className="badge badge-amber">Requires Funding</span>
              )}
            </div>
            <div className="stat-sub">Coverage: {couponPoolBalance > 0n && totalLiability > 0n ? `${((Number(couponPoolBalance) / Number(totalLiability)) * 100).toFixed(0)}%` : "0%"}</div>
          </div>

          <div className="stat-box">
            <div className="stat-label">Total Eligible Holders</div>
            <div className="stat-value font-mono">{holders.length}</div>
            <div className="stat-sub">Verified tokenholders</div>
          </div>
        </div>
      </div>

      {/* 2-Column Action Grid: Period Selector & Pool Funding */}
      <div className="grid-2">
        {/* Card 1: Select Period & Snapshot Trigger */}
        <div className="card" style={{ display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
          <div>
            <div className="card-header">
              <div>
                <h3 className="card-title">
                  <Calendar size={17} color="#3b82f6" /> 1. Select Period & Record Snapshot
                </h3>
                <p className="card-subtitle">Select the payment cycle and write tokenholder balances on-chain.</p>
              </div>
            </div>

            <div className="input-group">
              <label className="input-label" htmlFor="periodSelect">Select Payment Period</label>
              <div style={{ display: "flex", gap: "0.5rem" }}>
                <input
                  id="periodSelect"
                  className="input-field font-mono"
                  type="number"
                  min="1"
                  step="1"
                  value={selectedPeriod}
                  onChange={(e) => setSelectedPeriod(e.target.value.trim())}
                  placeholder="e.g. 1"
                />
              </div>
            </div>

            <div style={{ fontSize: "0.8rem", color: "var(--text-secondary)", marginTop: "0.5rem", lineHeight: 1.5 }}>
              Active on-chain periods: <b className="font-mono">{activePeriods.join(", ")}</b>.
              Recording a snapshot seals the eligible coupon claim amount for each wallet.
            </div>
          </div>

          <div style={{ marginTop: "1.25rem" }}>
            {snapshotStep && (
              <div className="alert-banner info" style={{ marginBottom: "0.75rem" }}>
                <RefreshCw size={13} className="spin" />
                <span style={{ fontSize: "0.78rem" }}>{snapshotStep}</span>
              </div>
            )}

            <button
              className="btn btn-primary"
              disabled={snapshotBusy || holders.length === 0}
              onClick={handleRecordSnapshot}
              style={{ width: "100%", justifyContent: "center", gap: 4 }}
            >
              <FileCheck size={14} />
              <span>{snapshotBusy ? "Recording on Chain..." : `Record Period ${selectedPeriod} Snapshot`}</span>
            </button>
          </div>
        </div>

        {/* Card 2: Fund the Coupon Pool */}
        <div className="card" style={{ display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
          <div>
            <div className="card-header">
              <div>
                <h3 className="card-title">
                  <Coins size={17} color="#10b981" /> 2. Fund Coupon Pool Liquidity
                </h3>
                <p className="card-subtitle">Deposit MockUSDC into the distributor contract for investor claims.</p>
              </div>
            </div>

            <form onSubmit={handleFundCouponPool} style={{ display: "flex", flexDirection: "column", gap: "0.75rem" }}>
              <div className="input-group">
                <label className="input-label" htmlFor="fundAmtInput">Deposit Amount (MockUSDC)</label>
                <div style={{ display: "flex", gap: "0.5rem" }}>
                  <input
                    id="fundAmtInput"
                    className="input-field font-mono"
                    type="number"
                    step="any"
                    min="1"
                    placeholder="e.g. 5000"
                    value={fundAmount}
                    onChange={(e) => setFundAmount(e.target.value)}
                  />
                  <button
                    type="button"
                    className="btn btn-secondary btn-sm"
                    onClick={() => setFundAmount(totalLiabilityFormatted.replace(/,/g, ""))}
                  >
                    Match Liability
                  </button>
                </div>
              </div>

              <div style={{ fontSize: "0.78rem", color: "var(--text-muted)" }}>
                Your Wallet Balance: <b className="font-mono">${fmtNumber(fromUnits(usdcBalance, USDC_DECIMALS))} USDC</b>
              </div>

              {fundingStep && (
                <div className="alert-banner info" style={{ margin: 0 }}>
                  <RefreshCw size={13} className="spin" />
                  <span style={{ fontSize: "0.78rem" }}>{fundingStep}</span>
                </div>
              )}

              <button
                type="submit"
                className="btn btn-emerald"
                disabled={fundingBusy || !fundAmount || Number(fundAmount) <= 0}
                style={{ width: "100%", justifyContent: "center", gap: 4, marginTop: "0.5rem" }}
              >
                <DollarSign size={14} />
                <span>{fundingBusy ? "Funding..." : "Deposit Funds to Pool"}</span>
              </button>
            </form>
          </div>
        </div>
      </div>

      {/* Eligible Tokenholders & Claim Tracking Table */}
      <div className="card">
        <div className="card-header">
          <div>
            <h3 className="card-title">
              <Users size={17} color="#f59e0b" /> Eligible Bondholders & Period {selectedPeriod} Claim Status
            </h3>
            <p className="card-subtitle">Live on-chain claim tracking (`hasClaimed` and snapshot balances).</p>
          </div>
        </div>

        <div className="table-container">
          <table className="data-table">
            <thead>
              <tr>
                <th>Holder Address</th>
                <th>Current Bond Balance</th>
                <th>Snapshot Balance</th>
                <th>Calculated Coupon</th>
                <th>Claim Status</th>
              </tr>
            </thead>
            <tbody>
              {holders.length === 0 ? (
                <tr>
                  <td colSpan={5} style={{ textAlign: "center", color: "var(--text-muted)", padding: "2rem" }}>
                    No tokenholders detected on this contract yet.
                  </td>
                </tr>
              ) : (
                holders.map((h, i) => (
                  <tr key={h.address || i}>
                    <td className="font-mono">{h.address}</td>
                    <td className="font-mono">{fmtNumber(fromUnits(h.balance, BOND_DECIMALS))} Bonds</td>
                    <td className="font-mono">{fmtNumber(fromUnits(h.snapBal, BOND_DECIMALS))} Bonds</td>
                    <td className="font-mono" style={{ color: "var(--accent-emerald)", fontWeight: 700 }}>
                      ${fmtNumber(fromUnits(h.calculatedCoupon, USDC_DECIMALS))} USDC
                    </td>
                    <td>
                      {h.hasClaimed ? (
                        <span className="badge badge-emerald">Claimed / Paid</span>
                      ) : h.snapBal > 0n ? (
                        <span className="badge badge-amber">Unclaimed</span>
                      ) : (
                        <span className="badge">No Snapshot</span>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Faucet Modal */}
      <TestUsdcFaucetModal
        isOpen={faucetOpen}
        onClose={() => setFaucetOpen(false)}
        initialAmount="10000"
        onSuccess={() => {
          setRefreshTrigger((n) => n + 1);
          loadAdminData();
        }}
      />
    </div>
  );
}

