import React, { useState, useEffect } from "react";
import { useAuth } from "../context/AuthContext";
import SuperAdminPanel from "./roles/SuperAdminPanel";
import ComplianceOfficerPanel from "./roles/ComplianceOfficerPanel";
import IssuerPanel from "./roles/IssuerPanel";
import AdminDashboardView from "./AdminDashboardView";
import AdminAuditLogs from "./AdminAuditLogs";
import Transparency from "./Transparency";
import {
  ShieldAlert,
  ShieldCheck,
  Layers,
  ArrowLeft,
  LogOut,
  LayoutDashboard,
  History,
  Activity,
  Sparkles,
  Key,
} from "lucide-react";
import { shortAddr } from "../lib/utils";

export default function InstitutionalPortal({ onSwitchToInvestor }) {
  const { account, user, roles, isInstitutional, logout } = useAuth();

  // Active role panel: "super_admin" | "compliance" | "issuer" | "overview" | "audit" | "oracles"
  const [activeRolePanel, setActiveRolePanel] = useState("super_admin");

  // Determine initial role view on load
  useEffect(() => {
    if (roles?.isMasterAdmin || roles?.admin) {
      setActiveRolePanel("super_admin");
    } else if (roles?.compliance) {
      setActiveRolePanel("compliance");
    } else if (roles?.issuer) {
      setActiveRolePanel("issuer");
    } else if (user?.role === "compliance") {
      setActiveRolePanel("compliance");
    } else if (user?.role === "issuer") {
      setActiveRolePanel("issuer");
    }
  }, [roles, user]);

  return (
    <div style={{ minHeight: "calc(100vh - 65px)", backgroundColor: "var(--bg-app)", padding: "1.5rem 2rem" }}>
      <div style={{ maxWidth: 1400, margin: "0 auto" }}>
        {/* Top Role Switcher Bar */}
        <div className="role-switcher-bar">
          <div style={{ display: "flex", alignItems: "center", gap: "0.85rem" }}>
            <div
              style={{
                width: 32,
                height: 32,
                borderRadius: "var(--radius-sm)",
                background: "linear-gradient(135deg, #f59e0b 0%, #d97706 100%)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                color: "#fff",
                fontWeight: 800,
                fontSize: "0.85rem",
              }}
            >
              A
            </div>
            <div>
              <div style={{ fontSize: "0.88rem", fontWeight: 900, color: "#fff", letterSpacing: "-0.01em" }}>
                AURA INSTITUTIONAL TERMINAL
              </div>
              <div style={{ fontSize: "0.7rem", color: "var(--text-muted)" }}>
                Connected: <span className="font-mono" style={{ color: "#60a5fa" }}>{shortAddr(account)}</span>
                {roles?.isMasterAdmin && (
                  <span className="badge badge-amber" style={{ marginLeft: "0.4rem", fontSize: "0.6rem" }}>
                    MASTER ADMIN WALLET
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* 3 Dedicated Role Panels Switcher */}
          <div className="role-pills">
            <button
              className={`role-pill-btn ${activeRolePanel === "super_admin" ? "active admin" : ""}`}
              onClick={() => setActiveRolePanel("super_admin")}
              title="Manage users, roles, platform settings and issuers"
            >
              <ShieldAlert size={14} />
              <span>Super Admin</span>
            </button>

            <button
              className={`role-pill-btn ${activeRolePanel === "compliance" ? "active compliance" : ""}`}
              onClick={() => setActiveRolePanel("compliance")}
              title="Review KYC, approve/reject and manage whitelist"
            >
              <ShieldCheck size={14} />
              <span>Compliance Officer</span>
            </button>

            <button
              className={`role-pill-btn ${activeRolePanel === "issuer" ? "active issuer" : ""}`}
              onClick={() => setActiveRolePanel("issuer")}
              title="Create offerings, fund coupons and manage issuance"
            >
              <Layers size={14} />
              <span>Issuer</span>
            </button>
          </div>

          {/* Auxiliary & Navigation buttons */}
          <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
            <button
              className={`btn btn-sm ${activeRolePanel === "overview" ? "btn-primary" : "btn-secondary"}`}
              onClick={() => setActiveRolePanel("overview")}
              style={{ fontSize: "0.75rem" }}
            >
              <LayoutDashboard size={13} />
              <span>Metrics</span>
            </button>

            <button
              className={`btn btn-sm ${activeRolePanel === "audit" ? "btn-primary" : "btn-secondary"}`}
              onClick={() => setActiveRolePanel("audit")}
              style={{ fontSize: "0.75rem" }}
            >
              <History size={13} />
              <span>Audit Trail</span>
            </button>

            <button
              className="btn btn-secondary btn-sm"
              onClick={onSwitchToInvestor}
              style={{ fontSize: "0.75rem" }}
            >
              <ArrowLeft size={13} />
              <span>Investor View</span>
            </button>

            <button
              className="btn btn-secondary btn-sm"
              onClick={logout}
              style={{ fontSize: "0.75rem", color: "var(--accent-rose)" }}
            >
              <LogOut size={13} />
            </button>
          </div>
        </div>

        {/* Panel Content Rendering */}
        <main>
          {activeRolePanel === "super_admin" && <SuperAdminPanel />}
          {activeRolePanel === "compliance" && <ComplianceOfficerPanel />}
          {activeRolePanel === "issuer" && <IssuerPanel />}
          {activeRolePanel === "overview" && <AdminDashboardView onNavigateTab={(tab) => {
            if (tab === "kyc") setActiveRolePanel("compliance");
            else if (tab === "issuance" || tab === "finance") setActiveRolePanel("issuer");
            else if (tab === "investors" || tab === "console") setActiveRolePanel("super_admin");
            else if (tab === "audit") setActiveRolePanel("audit");
          }} />}
          {activeRolePanel === "audit" && <AdminAuditLogs />}
        </main>
      </div>
    </div>
  );
}
