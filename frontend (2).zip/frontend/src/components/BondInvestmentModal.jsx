import React, { useState } from "react";
import { getContract, BOND_DECIMALS, USDC_DECIMALS, txUrl } from "../contracts/platform";
import { toUnits, fromUnits, fmtNumber, shortAddr } from "../lib/utils";
import { useAuth } from "../context/AuthContext";
import { useToast } from "./Toast";
import { Modal } from "./ui";
import {
  Sparkles,
  ShieldCheck,
  AlertCircle,
  ExternalLink,
  CheckCircle2,
  Coins,
  ArrowRight,
  TrendingUp,
  Clock,
  Layers,
} from "lucide-react";

export default function BondInvestmentModal({
  isOpen,
  onClose,
  lot,
  terms,
  network,
  onSuccess,
}) {
  const { account, signer, isKycVerified, isAuthenticated } = useAuth();
  const toast = useToast();

  const [busy, setBusy] = useState(false);
  const [stepText, setStepText] = useState("");
  const [txHash, setTxHash] = useState(null);
  const [error, setError] = useState(null);
  const [usdcBalance, setUsdcBalance] = useState(null);

  // Load USDC balance when modal opens
  React.useEffect(() => {
    let cancelled = false;
    if (account && signer && isOpen) {
      (async () => {
        try {
          const usdc = getContract("MockUSDC", signer, network);
          const bal = await usdc.balanceOf(account);
          if (!cancelled) setUsdcBalance(bal);
        } catch (e) {
          console.warn("Could not load USDC balance:", e);
        }
      })();
    }
    return () => {
      cancelled = true;
    };
  }, [account, signer, network, isOpen]);

  if (!isOpen || !lot) return null;

  const lotBondsFormatted = fmtNumber(fromUnits(lot.bondAmount, BOND_DECIMALS), 4);
  const lotPriceFormatted = fmtNumber(fromUnits(lot.price, USDC_DECIMALS));
  const perBondFormatted = fmtNumber(fromUnits(lot.per || (lot.price * 10n ** BigInt(BOND_DECIMALS)) / lot.bondAmount, USDC_DECIMALS));
  const couponRatePct = terms ? (terms.couponRateBps / 100).toFixed(2) : "8.00";

  // Calculate annual estimated coupon income on this lot
  const annualCouponIncome = terms
    ? (Number(fromUnits(lot.bondAmount, BOND_DECIMALS)) * Number(fromUnits(terms.faceValue, USDC_DECIMALS)) * (terms.couponRateBps / 10000)).toFixed(2)
    : "0.00";

  const hasEnoughUSDC = usdcBalance !== null ? usdcBalance >= lot.price : true;

  const handleInvest = async () => {
    setError(null);
    setTxHash(null);

    // Validations
    if (!account || !signer) {
      return setError("Please connect your MetaMask wallet on Sepolia.");
    }
    if (!isKycVerified) {
      return setError("Your wallet is not KYC-verified. Please complete verification first.");
    }
    if (usdcBalance !== null && usdcBalance < lot.price) {
      return setError(`Insufficient MockUSDC balance. You need $${lotPriceFormatted} MockUSDC. Use the Faucet in your Dashboard to claim test funds.`);
    }

    setBusy(true);
    try {
      const usdc = getContract("MockUSDC", signer, network);
      const market = getContract("Marketplace", signer, network);
      const marketAddr = await market.getAddress();

      // Check allowance
      setStepText("Step 1/2: Checking MockUSDC allowance...");
      const allowance = await usdc.allowance(account, marketAddr);

      if (allowance < lot.price) {
        setStepText(`Step 1/2: Approving $${lotPriceFormatted} MockUSDC (confirm in MetaMask)...`);
        const approveTx = await usdc.approve(marketAddr, lot.price);
        await approveTx.wait();
      }

      setStepText(`Step 2/2: Purchasing Bond Lot #${lot.id} (confirm in MetaMask)...`);
      const buyTx = await market.buy(lot.id);
      const receipt = await buyTx.wait();

      setTxHash(receipt.hash);
      setStepText("Purchase confirmed on Sepolia!");
      toast.success(`Successfully invested! ${lotBondsFormatted} bonds transferred to your wallet.`);

      if (onSuccess) onSuccess();
    } catch (err) {
      console.error(err);
      if (err.code === "ACTION_REJECTED" || err.code === 4001 || /user rejected/i.test(err.message || "")) {
        setError("Transaction was cancelled in your wallet.");
      } else {
        setError(err.reason || err.shortMessage || err.message || "Investment transaction failed");
      }
    } finally {
      setBusy(false);
    }
  };

  const etherscanLink = txHash ? txUrl(network, txHash) : null;

  return (
    <Modal title={`Primary Bond Offering — Lot #${lot.id}`} onClose={onClose}>
      {txHash ? (
        <div style={{ textAlign: "center", padding: "1rem 0" }}>
          <div
            style={{
              width: 56,
              height: 56,
              borderRadius: "50%",
              background: "rgba(16, 185, 129, 0.15)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              margin: "0 auto 1rem auto",
            }}
          >
            <CheckCircle2 size={32} color="#10b981" />
          </div>
          <h4 style={{ fontSize: "1.2rem", fontWeight: 800 }}>Investment Successful!</h4>
          <p style={{ color: "var(--text-secondary)", fontSize: "0.85rem", marginTop: "0.35rem" }}>
            You have acquired <b>{lotBondsFormatted} {terms?.symbol || "CB28"}</b> bonds.
            They are now held in your whitelisted wallet.
          </p>

          {etherscanLink && (
            <div style={{ marginTop: "1.25rem" }}>
              <a
                href={etherscanLink}
                target="_blank"
                rel="noopener noreferrer"
                className="btn btn-secondary btn-sm font-mono"
                style={{ display: "inline-flex", gap: "0.4rem", color: "var(--accent-emerald)" }}
              >
                <span>View on Sepolia Etherscan</span>
                <ExternalLink size={12} />
              </a>
            </div>
          )}

          <button className="btn btn-primary" onClick={onClose} style={{ marginTop: "1.5rem", width: "100%" }}>
            Done
          </button>
        </div>
      ) : (
        <div>
          {/* Eligibility Checklist */}
          <div
            style={{
              padding: "0.75rem 1rem",
              background: "rgba(21, 29, 44, 0.6)",
              border: "1px solid var(--border-subtle)",
              borderRadius: "var(--radius-md)",
              marginBottom: "1.25rem",
              fontSize: "0.78rem",
            }}
          >
            <div style={{ fontWeight: 700, marginBottom: "0.4rem", color: "var(--text-primary)" }}>
              Investment Eligibility Checks
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: "0.3rem" }}>
              <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
                {account ? <CheckCircle2 size={13} color="#10b981" /> : <AlertCircle size={13} color="#f59e0b" />}
                <span style={{ color: account ? "var(--text-secondary)" : "#f59e0b" }}>
                  Wallet Connected: {account ? shortAddr(account) : "Disconnected"}
                </span>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
                {isKycVerified ? <CheckCircle2 size={13} color="#10b981" /> : <AlertCircle size={13} color="#f43f5e" />}
                <span style={{ color: isKycVerified ? "var(--text-secondary)" : "#f43f5e" }}>
                  KYC Registry Status: {isKycVerified ? "Approved & Whitelisted" : "Not Whitelisted (KYC Required)"}
                </span>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
                {hasEnoughUSDC ? <CheckCircle2 size={13} color="#10b981" /> : <AlertCircle size={13} color="#f59e0b" />}
                <span style={{ color: hasEnoughUSDC ? "var(--text-secondary)" : "#f59e0b" }}>
                  MockUSDC Balance: {usdcBalance !== null ? `$${fmtNumber(fromUnits(usdcBalance, USDC_DECIMALS))}` : "Checking..."}
                </span>
              </div>
            </div>
          </div>

          {/* Investment Summary Details */}
          <div
            style={{
              background: "var(--bg-input)",
              borderRadius: "var(--radius-md)",
              border: "1px solid var(--border-subtle)",
              padding: "1rem",
              marginBottom: "1.25rem",
            }}
          >
            <div style={{ display: "flex", justifyContent: "space-between", padding: "0.4rem 0", fontSize: "0.825rem" }}>
              <span style={{ color: "var(--text-secondary)" }}>Bond Asset</span>
              <span style={{ fontWeight: 700 }}>{terms ? `${terms.name} (${terms.symbol})` : "Corporate Bond 2028"}</span>
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", padding: "0.4rem 0", fontSize: "0.825rem" }}>
              <span style={{ color: "var(--text-secondary)" }}>Offered Lot Size</span>
              <span className="font-mono" style={{ fontWeight: 700 }}>{lotBondsFormatted} Bonds</span>
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", padding: "0.4rem 0", fontSize: "0.825rem" }}>
              <span style={{ color: "var(--text-secondary)" }}>Price Per Bond</span>
              <span className="font-mono">${perBondFormatted} USDC</span>
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", padding: "0.4rem 0", fontSize: "0.825rem" }}>
              <span style={{ color: "var(--text-secondary)" }}>Annual Coupon Yield</span>
              <span style={{ color: "var(--accent-emerald)", fontWeight: 700 }}>{couponRatePct}% p.a.</span>
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", padding: "0.4rem 0", fontSize: "0.825rem" }}>
              <span style={{ color: "var(--text-secondary)" }}>Est. Annual Coupon Income</span>
              <span className="font-mono" style={{ color: "#34d399", fontWeight: 700 }}>+${annualCouponIncome} USDC</span>
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", padding: "0.4rem 0", fontSize: "0.825rem" }}>
              <span style={{ color: "var(--text-secondary)" }}>Maturity Date</span>
              <span>{terms ? terms.maturity.toLocaleDateString() : "May 15, 2028"}</span>
            </div>
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                padding: "0.6rem 0 0.2rem 0",
                marginTop: "0.5rem",
                borderTop: "1px solid var(--border-subtle)",
                fontSize: "0.95rem",
              }}
            >
              <span style={{ fontWeight: 700 }}>Total Investment Amount</span>
              <span className="font-mono" style={{ fontWeight: 800, color: "var(--accent-blue)" }}>
                ${lotPriceFormatted} USDC
              </span>
            </div>
          </div>

          {error && (
            <div className="alert-banner error" style={{ marginBottom: "1rem" }}>
              <AlertCircle size={14} />
              <span>{error}</span>
            </div>
          )}

          {busy && (
            <div className="alert-banner info" style={{ marginBottom: "1rem" }}>
              <Clock size={14} className="animate-spin" />
              <span>{stepText}</span>
            </div>
          )}

          <div style={{ display: "flex", gap: "0.75rem", justifyContent: "flex-end", marginTop: "1rem" }}>
            <button className="btn btn-secondary btn-sm" onClick={onClose} disabled={busy}>
              Cancel
            </button>
            <button
              className="btn btn-primary btn-sm"
              onClick={handleInvest}
              disabled={busy || !account || !isKycVerified || !hasEnoughUSDC}
            >
              <span>{busy ? "Confirming in Wallet..." : "Confirm & Execute Investment"}</span>
              <ArrowRight size={14} />
            </button>
          </div>
        </div>
      )}
    </Modal>
  );
}

