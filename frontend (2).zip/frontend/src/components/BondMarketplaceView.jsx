import React, { useState, useEffect, useCallback } from "react";
import { ethers } from "ethers";
import {
  getContract,
  fetchOrders,
  loadTerms,
  BOND_DECIMALS,
  USDC_DECIMALS,
  addressUrl,
} from "../contracts/platform";
import { fromUnits, fmtNumber, shortAddr } from "../lib/utils";
import { useAuth } from "../context/AuthContext";
import { useToast } from "./Toast";
import BondInvestmentModal from "./BondInvestmentModal";
import Marketplace from "./Marketplace";
import {
  Search,
  Filter,
  Sparkles,
  Layers,
  ArrowRight,
  TrendingUp,
  ShieldCheck,
  RefreshCw,
  Info,
  Calendar,
  Building,
  DollarSign,
  Tag,
} from "lucide-react";

export default function BondMarketplaceView({ onNavigateToKyc }) {
  const { account, readProvider, signer, network, isKycVerified, refreshTrigger, setRefreshTrigger } = useAuth();
  const toast = useToast();

  const [activeTab, setActiveTab] = useState("primary"); // "primary" | "secondary"
  const [terms, setTerms] = useState(null);
  const [primaryLots, setPrimaryLots] = useState([]);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState("");
  const [selectedLot, setSelectedLot] = useState(null);
  const [termsModalOpen, setTermsModalOpen] = useState(false);

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const t = await loadTerms(readProvider, network);
      setTerms(t);

      const market = getContract("Marketplace", readProvider, network);
      const bond = getContract("BondToken", readProvider, network);
      const { orders } = await fetchOrders(market, 200);

      const active = orders.filter((o) => o.isActive);
      const sellers = [...new Set(active.map((o) => o.seller))];
      const flags = await Promise.all(sellers.map((s) => bond.hasRole(ethers.id("ISSUER_ROLE"), s)));
      const issuers = new Set(sellers.filter((_, i) => flags[i]).map((s) => s.toLowerCase()));

      const issuerLots = active
        .filter((o) => issuers.has(o.seller.toLowerCase()))
        .map((o) => ({
          ...o,
          per: (o.price * 10n ** BigInt(BOND_DECIMALS)) / o.bondAmount,
        }))
        .sort((a, b) => (a.per < b.per ? -1 : a.per > b.per ? 1 : 0));

      setPrimaryLots(issuerLots);
    } catch (err) {
      console.warn("Could not load marketplace data:", err);
    } finally {
      setLoading(false);
    }
  }, [readProvider, network]);

  useEffect(() => {
    loadData();
  }, [loadData, refreshTrigger]);

  const filteredLots = primaryLots.filter((lot) => {
    if (!search) return true;
    const s = search.toLowerCase();
    return (
      String(lot.id).includes(s) ||
      lot.seller.toLowerCase().includes(s) ||
      (terms?.name && terms.name.toLowerCase().includes(s))
    );
  });

  const couponPct = terms ? (terms.couponRateBps / 100).toFixed(2) : "8.00";
  const faceVal = terms ? fromUnits(terms.faceValue, USDC_DECIMALS) : "1,000";

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "1.75rem" }}>
      {/* Header Banner */}
      <div className="card">
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: "1rem" }}>
          <div>
            <div style={{ display: "flex", gap: "0.5rem", alignItems: "center" }}>
              <span className="badge badge-blue">RWA CAPITAL MARKETS</span>
              <span className="badge badge-emerald">Fixed Income</span>
            </div>
            <h2 style={{ fontSize: "1.6rem", fontWeight: 800, marginTop: "0.35rem" }}>
              Bond Marketplace
            </h2>
            <p style={{ color: "var(--text-secondary)", fontSize: "0.85rem", marginTop: "0.25rem" }}>
              Explore primary issuance tranches from verified issuers or trade peer-to-peer on the secondary order book.
            </p>
          </div>

          <div style={{ display: "flex", gap: "0.5rem" }}>
            <button
              className={`btn btn-sm ${activeTab === "primary" ? "btn-primary" : "btn-secondary"}`}
              onClick={() => setActiveTab("primary")}
            >
              <Sparkles size={14} /> Primary Offerings ({primaryLots.length})
            </button>
            <button
              className={`btn btn-sm ${activeTab === "secondary" ? "btn-primary" : "btn-secondary"}`}
              onClick={() => setActiveTab("secondary")}
            >
              <Tag size={14} /> Secondary Order Book
            </button>
            <button
              className="btn-icon"
              onClick={() => { setRefreshTrigger((n) => n + 1); loadData(); }}
              aria-label="Refresh marketplace"
              title="Refresh"
            >
              <RefreshCw size={14} className={loading ? "animate-spin" : ""} />
            </button>
          </div>
        </div>
      </div>

      {activeTab === "primary" ? (
        <>
          {/* Search & Filter Bar */}
          <div className="filter-bar">
            <div className="search-input-wrapper">
              <Search size={15} className="search-icon" />
              <input
                type="text"
                className="search-input"
                placeholder="Search offerings by ID, issuer address, or bond symbol..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
          </div>

          {/* Primary Offering Cards Grid */}
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(320px, 1fr))", gap: "1.25rem" }}>
            {filteredLots.length === 0 ? (
              <div className="card" style={{ gridColumn: "1 / -1", textAlign: "center", padding: "3rem 1.5rem" }}>
                <Layers size={36} color="#64748b" style={{ margin: "0 auto 0.75rem auto", opacity: 0.6 }} />
                <h3 style={{ fontSize: "1.1rem", fontWeight: 700 }}>No Primary Offerings Match Filter</h3>
                <p style={{ color: "var(--text-secondary)", fontSize: "0.85rem", marginTop: "0.25rem", maxWidth: 450, margin: "0.25rem auto 1rem auto" }}>
                  {loading
                    ? "Querying blockchain contracts..."
                    : "The issuer currently has no open primary offering lots on the market. You can explore the Secondary Order Book or wait for the next tranche."}
                </p>
                <button className="btn btn-secondary btn-sm" onClick={() => setActiveTab("secondary")}>
                  Browse Secondary Market
                </button>
              </div>
            ) : (
              filteredLots.map((lot) => {
                const bondQty = fmtNumber(fromUnits(lot.bondAmount, BOND_DECIMALS), 4);
                const totalPrice = fmtNumber(fromUnits(lot.price, USDC_DECIMALS));
                const perBond = fmtNumber(fromUnits(lot.per, USDC_DECIMALS));
                const isSeller = account && lot.seller.toLowerCase() === account.toLowerCase();

                return (
                  <div
                    key={lot.id}
                    className="card"
                    style={{
                      display: "flex",
                      flexDirection: "column",
                      justifyContent: "space-between",
                      transition: "transform 0.15s, border-color 0.15s",
                    }}
                  >
                    <div>
                      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "0.75rem" }}>
                        <span className="badge badge-blue">PRIMARY LOT #{lot.id}</span>
                        <span className="badge badge-emerald">{couponPct}% p.a.</span>
                      </div>

                      <h3 style={{ fontSize: "1.2rem", fontWeight: 800 }}>
                        {terms ? `${terms.name}` : "Corporate Bond 2028"}
                      </h3>
                      <div className="font-mono" style={{ fontSize: "0.75rem", color: "var(--text-muted)", marginTop: "0.2rem" }}>
                        Issuer: {shortAddr(lot.seller)}
                      </div>

                      <div
                        style={{
                          display: "grid",
                          gridTemplateColumns: "1fr 1fr",
                          gap: "0.75rem",
                          margin: "1.25rem 0",
                          padding: "0.85rem",
                          background: "var(--bg-input)",
                          borderRadius: "var(--radius-md)",
                          border: "1px solid var(--border-subtle)",
                        }}
                      >
                        <div>
                          <div style={{ fontSize: "0.7rem", color: "var(--text-muted)", textTransform: "uppercase" }}>Quantity</div>
                          <div className="font-mono" style={{ fontSize: "1.05rem", fontWeight: 700 }}>
                            {bondQty} {terms?.symbol || "CB28"}
                          </div>
                        </div>
                        <div>
                          <div style={{ fontSize: "0.7rem", color: "var(--text-muted)", textTransform: "uppercase" }}>Price / Bond</div>
                          <div className="font-mono" style={{ fontSize: "1.05rem", fontWeight: 700 }}>
                            ${perBond} USDC
                          </div>
                        </div>
                        <div>
                          <div style={{ fontSize: "0.7rem", color: "var(--text-muted)", textTransform: "uppercase" }}>Total Investment</div>
                          <div className="font-mono" style={{ fontSize: "1.05rem", fontWeight: 800, color: "var(--accent-blue)" }}>
                            ${totalPrice}
                          </div>
                        </div>
                        <div>
                          <div style={{ fontSize: "0.7rem", color: "var(--text-muted)", textTransform: "uppercase" }}>Maturity</div>
                          <div style={{ fontSize: "0.85rem", fontWeight: 600 }}>
                            {terms ? terms.maturity.toLocaleDateString() : "May 15, 2028"}
                          </div>
                        </div>
                      </div>
                    </div>

                    <div style={{ display: "flex", gap: "0.5rem" }}>
                      <button
                        className="btn btn-primary"
                        onClick={() => setSelectedLot(lot)}
                        disabled={isSeller}
                        style={{ flex: 1 }}
                      >
                        <DollarSign size={14} />
                        <span>{isSeller ? "Your Offering" : "Invest in Lot"}</span>
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </>
      ) : (
        <Marketplace
          account={account}
          provider={readProvider}
          signer={signer}
          network={network}
          isKycVerified={isKycVerified}
          refreshTrigger={refreshTrigger}
          setRefreshTrigger={setRefreshTrigger}
        />
      )}

      {/* Investment Modal */}
      {selectedLot && (
        <BondInvestmentModal
          isOpen={Boolean(selectedLot)}
          onClose={() => setSelectedLot(null)}
          lot={selectedLot}
          terms={terms}
          network={network}
          onSuccess={() => {
            setSelectedLot(null);
            setRefreshTrigger((n) => n + 1);
            loadData();
          }}
        />
      )}
    </div>
  );
}

