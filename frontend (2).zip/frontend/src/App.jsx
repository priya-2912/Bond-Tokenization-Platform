import React, { useState, useEffect } from "react";
import { AuthProvider, useAuth } from "./context/AuthContext";
import { ToastProvider, useToast } from "./components/Toast";
import Navbar from "./components/Navbar";
import LandingPage from "./components/LandingPage";
import InvestorDashboard from "./components/InvestorDashboard";
import BondMarketplaceView from "./components/BondMarketplaceView";
import InvestorPortfolioView from "./components/InvestorPortfolioView";
import KycApplication from "./components/KycApplication";
import InvestorProfile from "./components/InvestorProfile";
import Transparency from "./components/Transparency";
import InstitutionalPortal from "./components/InstitutionalPortal";
import InvestorAuthModal from "./components/InvestorAuthModal";
import InstitutionalAuthModal from "./components/InstitutionalAuthModal";
import { EmptyState } from "./components/ui";
import { NETWORKS, isDeployed } from "./contracts/platform";
import { MASTER_ADMIN_WALLET } from "./lib/useRoles";
import { friendlyError } from "./lib/utils";

function MainPlatform() {
  const {
    account,
    readProvider,
    signer,
    network,
    user,
    isAuthenticated,
    isInstitutional,
    isKycVerified,
    chainOk,
    walletChainId,
    deployed,
    switchChain,
    refreshTrigger,
    setRefreshTrigger,
  } = useAuth();

  const toast = useToast();

  // Navigation state: "landing" | "investor" | "institutional"
  const [currentView, setCurrentView] = useState("landing");
  // Investor portal tab: "dashboard" | "marketplace" | "portfolio" | "kyc" | "profile" | "transparency"
  const [investorTab, setInvestorTab] = useState("dashboard");

  // Modals state
  const [investorAuthOpen, setInvestorAuthOpen] = useState(false);
  const [investorAuthMode, setInvestorAuthMode] = useState("signin");
  const [institutionalAuthOpen, setInstitutionalAuthOpen] = useState(false);
  const [notice, setNotice] = useState(null);

  // Auto-switch to institutional view if master admin wallet connects, or investor view if authenticated
  useEffect(() => {
    if (account && account.toLowerCase() === MASTER_ADMIN_WALLET) {
      if (currentView === "landing") {
        setCurrentView("institutional");
        toast.info("Master Admin wallet detected. Switched to Institutional Terminal.");
      }
    } else if (isAuthenticated && currentView === "landing") {
      setCurrentView("investor");
    }
  }, [account, isAuthenticated, currentView]);

  const openInvestorAuth = (mode = "signin") => {
    setInvestorAuthMode(mode);
    setInvestorAuthOpen(true);
  };

  const openInstitutionalAuth = () => {
    setInstitutionalAuthOpen(true);
  };

  const handleSwitchNetwork = async () => {
    try {
      await switchChain();
    } catch (err) {
      toast.error(`Could not switch network: ${friendlyError(err)}`);
    }
  };

  const common = {
    account,
    provider: readProvider,
    signer,
    network,
    refreshTrigger,
    setRefreshTrigger,
  };

  return (
    <div className="app-container">
      {/* Top Navbar */}
      <Navbar
        currentView={currentView}
        setCurrentView={setCurrentView}
        investorTab={investorTab}
        setInvestorTab={setInvestorTab}
        onOpenInvestorAuth={openInvestorAuth}
        onOpenInstitutionalAuth={openInstitutionalAuth}
      />

      {/* Main Content Area */}
      <main className={currentView === "institutional" ? "" : "main-content"}>
        {/* Network Mismatch Warning Banner */}
        {account && !chainOk && (
          <div className="alert-banner warn" style={{ margin: "1rem auto", maxWidth: 1240 }}>
            <span>
              Your wallet is connected to Chain ID {walletChainId}, but you are viewing {NETWORKS[network].label}.
              Transactions require switching your wallet.
            </span>
            <button className="btn btn-primary btn-sm" onClick={handleSwitchNetwork}>
              Switch to {NETWORKS[network].label}
            </button>
          </div>
        )}

        {/* Missing Deployment Warning */}
        {!deployed ? (
          <EmptyState title={`No deployment found for ${NETWORKS[network].label}`}>
            <p>
              <span className="font-mono">shared/addresses.json</span> has no complete entry for <b>{network}</b>.
            </p>
            <p style={{ marginTop: "0.5rem" }}>
              Run <span className="font-mono">npm run deploy:{network === "sepolia" ? "sepolia" : "local"}</span> in the project root.
            </p>
          </EmptyState>
        ) : (
          <>
            {/* VIEW 1: Public Landing Page */}
            {currentView === "landing" && (
              <LandingPage
                provider={readProvider}
                network={network}
                onExploreMarketplace={() => {
                  setCurrentView("investor");
                  setInvestorTab("marketplace");
                }}
                onInvestorLogin={() => openInvestorAuth("signin")}
                onInstitutionalLogin={openInstitutionalAuth}
                onSignUp={() => openInvestorAuth("signup")}
              />
            )}

            {/* VIEW 2: Investor Portal Experience */}
            {currentView === "investor" && (
              <>
                {investorTab === "dashboard" && (
                  <InvestorDashboard {...common} isKycVerified={isKycVerified} />
                )}
                {investorTab === "marketplace" && (
                  <BondMarketplaceView onNavigateToKyc={() => setInvestorTab("kyc")} />
                )}
                {investorTab === "portfolio" && <InvestorPortfolioView />}
                {investorTab === "kyc" && (
                  <KycApplication
                    account={account}
                    isKycVerified={isKycVerified}
                    refreshTrigger={refreshTrigger}
                    onDone={() => setRefreshTrigger((n) => n + 1)}
                  />
                )}
                {investorTab === "profile" && (
                  <InvestorProfile onNavigateToKyc={() => setInvestorTab("kyc")} />
                )}
                {investorTab === "transparency" && (
                  <Transparency
                    provider={readProvider}
                    network={network}
                    refreshTrigger={refreshTrigger}
                    setRefreshTrigger={setRefreshTrigger}
                  />
                )}
              </>
            )}

            {/* VIEW 3: Institutional & Compliance Portal Experience */}
            {currentView === "institutional" && (
              <InstitutionalPortal onSwitchToInvestor={() => setCurrentView("investor")} />
            )}
          </>
        )}
      </main>

      {/* Global Modals */}
      <InvestorAuthModal
        isOpen={investorAuthOpen}
        onClose={() => setInvestorAuthOpen(false)}
        initialMode={investorAuthMode}
        onSuccess={() => {
          setCurrentView("investor");
          setInvestorTab("dashboard");
        }}
      />

      <InstitutionalAuthModal
        isOpen={institutionalAuthOpen}
        onClose={() => setInstitutionalAuthOpen(false)}
        onSuccess={() => {
          setCurrentView("institutional");
        }}
      />

      {/* Footer (Public & Investor view) */}
      {currentView !== "institutional" && (
        <footer
          style={{
            borderTop: "1px solid var(--border-subtle)",
            padding: "1.75rem 1.5rem",
            fontSize: "0.75rem",
            color: "var(--text-muted)",
            backgroundColor: "rgba(10, 14, 23, 0.95)",
            marginTop: "auto",
          }}
        >
          <div
            style={{
              maxWidth: "1240px",
              margin: "0 auto",
              display: "flex",
              justifyContent: "space-between",
              flexWrap: "wrap",
              gap: "0.75rem",
              alignItems: "center",
            }}
          >
            <div>
              <b>Aura Bonds</b> • Institutional Debt Tokenization Platform • Ethereum Sepolia Testnet
            </div>
            <div style={{ display: "flex", gap: "1rem" }}>
              <span>Compliant KYCRegistry</span>
              <span>•</span>
              <span>Proof of Reserves Guard</span>
              <span>•</span>
              <span>Chainlink Oracle Feeds</span>
              <span>•</span>
              <span>P2P Order Book Escrow</span>
            </div>
          </div>
        </footer>
      )}
    </div>
  );
}

export default function App() {
  return (
    <ToastProvider>
      <AuthProvider>
        <MainPlatform />
      </AuthProvider>
    </ToastProvider>
  );
}
