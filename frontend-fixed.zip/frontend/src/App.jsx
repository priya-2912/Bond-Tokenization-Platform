import React, { useState, useEffect, useMemo, useCallback, useRef } from "react";
import { ethers } from "ethers";
import Navbar from "./components/Navbar";
import InvestorDashboard from "./components/InvestorDashboard";
import Marketplace from "./components/Marketplace";
import AdminConsole from "./components/AdminConsole";
import Transparency from "./components/Transparency";
import { EmptyState } from "./components/ui";
import { useRoles } from "./lib/useRoles";
import { friendlyError } from "./lib/utils";
import { NETWORKS, getContract, getReadProvider, isDeployed, switchWalletNetwork } from "./contracts/platform";

export default function App() {
  const [account, setAccount] = useState(null);
  const [signer, setSigner] = useState(null);
  const [walletChainId, setWalletChainId] = useState(null);
  const [network, setNetwork] = useState("localhost");
  const [isKycVerified, setIsKycVerified] = useState(false);
  const [activeTab, setActiveTab] = useState("investor");
  const [refreshTrigger, setRefreshTrigger] = useState(0);
  const [notice, setNotice] = useState(null);
  const userDisconnected = useRef(false);

  const hasWallet = typeof window !== "undefined" && Boolean(window.ethereum);
  const readProvider = useMemo(() => getReadProvider(network), [network]);
  const deployed = isDeployed(network);
  const chainOk = walletChainId === NETWORKS[network].chainId;
  // Only hand a signer to the pages when the wallet is on the same chain as the selected network.
  const activeSigner = account && chainOk ? signer : null;
  const roles = useRoles(account, readProvider, network, refreshTrigger);

  const syncWallet = useCallback(async (requestAccounts = false) => {
    if (!window.ethereum) return null;
    const bp = new ethers.BrowserProvider(window.ethereum);
    const accounts = await bp.send(requestAccounts ? "eth_requestAccounts" : "eth_accounts", []);
    const chainHex = await bp.send("eth_chainId", []);
    const chainId = parseInt(chainHex, 16);
    setWalletChainId(chainId);
    if (accounts.length > 0 && !userDisconnected.current) {
      setAccount(ethers.getAddress(accounts[0]));
      setSigner(await bp.getSigner());
    } else {
      setAccount(null);
      setSigner(null);
    }
    return chainId;
  }, []);

  // Initial wallet read + live updates when the user switches account or chain in MetaMask.
  useEffect(() => {
    if (!window.ethereum) return undefined;
    (async () => {
      try {
        const chainId = await syncWallet(false);
        const match = Object.keys(NETWORKS).find((k) => NETWORKS[k].chainId === chainId);
        if (match) setNetwork(match);
      } catch (e) {
        console.warn("Could not read wallet state:", e);
      }
    })();
    const refresh = () => syncWallet(false).catch((e) => console.warn(e));
    if (window.ethereum.on) {
      window.ethereum.on("accountsChanged", refresh);
      window.ethereum.on("chainChanged", refresh);
    }
    return () => {
      if (window.ethereum.removeListener) {
        window.ethereum.removeListener("accountsChanged", refresh);
        window.ethereum.removeListener("chainChanged", refresh);
      }
    };
  }, [syncWallet]);

  // KYC status always comes from the selected network's registry.
  useEffect(() => {
    let cancelled = false;
    (async () => {
      if (!account || !deployed) {
        setIsKycVerified(false);
        return;
      }
      try {
        const kyc = getContract("KYCRegistry", readProvider, network);
        const verified = await kyc.isVerified(account);
        if (!cancelled) setIsKycVerified(verified);
      } catch (e) {
        console.warn("Error checking KYC status:", e);
        if (!cancelled) setIsKycVerified(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [account, readProvider, network, deployed, refreshTrigger]);

  const connectWallet = async () => {
    setNotice(null);
    if (!window.ethereum) {
      setNotice({ type: "warn", text: "No wallet found. Install MetaMask to connect. You can still browse in read-only mode." });
      return;
    }
    try {
      userDisconnected.current = false;
      await syncWallet(true);
    } catch (err) {
      setNotice({ type: "error", text: `Could not connect wallet: ${friendlyError(err)}` });
    }
  };

  const disconnect = () => {
    // MetaMask cannot be disconnected by a site; this just forgets the account in this page.
    userDisconnected.current = true;
    setAccount(null);
    setSigner(null);
  };

  const switchChain = async () => {
    setNotice(null);
    try {
      await switchWalletNetwork(network);
      await syncWallet(false);
    } catch (err) {
      setNotice({ type: "error", text: `Could not switch network: ${friendlyError(err)}` });
    }
  };

  const common = {
    account,
    provider: readProvider,
    signer: activeSigner,
    network,
    refreshTrigger,
    setRefreshTrigger,
  };

  return (
    <div className="app-container">
      <Navbar
        account={account}
        network={network}
        networks={NETWORKS}
        onSelectNetwork={setNetwork}
        connectWallet={connectWallet}
        disconnect={disconnect}
        isKycVerified={isKycVerified}
        roles={roles}
        chainOk={chainOk}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
      />

      <main className="main-content">
        {!hasWallet && (
          <div className="alert-banner warn">
            <span>No wallet detected: the site is read-only. Install MetaMask to send transactions.</span>
          </div>
        )}

        {hasWallet && account && !chainOk && (
          <div className="alert-banner warn">
            <span>
              Your wallet is on chain {walletChainId}, but you are viewing {NETWORKS[network].label}. Transactions are disabled until you switch.
            </span>
            <button className="btn btn-primary btn-sm" onClick={switchChain}>
              Switch wallet to {NETWORKS[network].label}
            </button>
          </div>
        )}

        {notice && (
          <div className={`alert-banner ${notice.type}`}>
            <span>{notice.text}</span>
            <button onClick={() => setNotice(null)} aria-label="Dismiss" style={{ background: "none", border: "none", color: "inherit", cursor: "pointer" }}>✕</button>
          </div>
        )}

        {!deployed ? (
          <EmptyState title={`No deployment found for ${NETWORKS[network].label}`}>
            <p>
              <span className="font-mono">shared/addresses.json</span> has no complete entry for <b>{network}</b>.
            </p>
            <p style={{ marginTop: "0.5rem" }}>
              Run <span className="font-mono">npm run deploy:{network === "sepolia" ? "sepolia" : "local"}</span> in the project root, then reload this page
              {network === "localhost" ? " (and keep npm run node running)." : "."}
            </p>
          </EmptyState>
        ) : (
          <>
            {activeTab === "investor" && <InvestorDashboard {...common} isKycVerified={isKycVerified} />}
            {activeTab === "marketplace" && <Marketplace {...common} isKycVerified={isKycVerified} />}
            {activeTab === "admin" && <AdminConsole {...common} roles={roles} />}
            {activeTab === "transparency" && <Transparency provider={readProvider} network={network} refreshTrigger={refreshTrigger} setRefreshTrigger={setRefreshTrigger} />}
          </>
        )}
      </main>

      <footer
        style={{
          borderTop: "1px solid var(--border-subtle)",
          padding: "1.75rem 1.5rem",
          textAlign: "center",
          fontSize: "0.75rem",
          color: "var(--text-muted)",
          backgroundColor: "rgba(10, 14, 23, 0.95)",
        }}
      >
        <div style={{ maxWidth: "1240px", margin: "0 auto", display: "flex", justifyContent: "space-between", flexWrap: "wrap", gap: "0.75rem", alignItems: "center" }}>
          <div>Aura Bonds Tokenization Platform • Testnet prototype, not an offer of securities</div>
          <div style={{ display: "flex", gap: "1rem" }}>
            <span>Compliant KYC Registry</span>
            <span>•</span>
            <span>Proof of Reserves (mock oracle)</span>
            <span>•</span>
            <span>Secondary Order Book</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
