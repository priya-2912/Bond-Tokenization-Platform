import React, { useState, useEffect, useCallback } from "react";
import { submitKyc, getKycStatus, ID_FILE_LIMIT, ID_FILE_TYPES, BACKEND_URL } from "../lib/backend";
import { ShieldCheck, FileText, UserCheck } from "lucide-react";

const STEPS = ["Submit application", "Under review", "Verified"];

/** Investor KYC: submit name + ID document to the compliance service, then follow the status. On-chain isVerified is the source of truth. */
export default function KycApplication({ account, isKycVerified, refreshTrigger, onDone }) {
  const [name, setName] = useState("");
  const [file, setFile] = useState(null);
  const [dummyOk, setDummyOk] = useState(false);
  const [remote, setRemote] = useState({ status: "none", unreachable: false });
  const [submitting, setSubmitting] = useState(false);
  const [msg, setMsg] = useState(null);

  const loadStatus = useCallback(async () => {
    if (!account) return;
    const r = await getKycStatus(account);
    if (r.ok) setRemote({ status: r.data.status, unreachable: false });
    else if (r.unreachable) setRemote({ status: "none", unreachable: true });
    else setRemote({ status: "none", unreachable: false }); // 404: no application yet
  }, [account]);

  useEffect(() => {
    loadStatus();
  }, [loadStatus, refreshTrigger]);

  // While an application is under review, check again every 15 seconds.
  useEffect(() => {
    if (remote.status !== "pending" || isKycVerified) return undefined;
    const t = setInterval(() => {
      loadStatus();
      onDone();
    }, 15000);
    return () => clearInterval(t);
  }, [remote.status, isKycVerified, loadStatus, onDone]);

  const current = isKycVerified ? 3 : remote.status === "pending" ? 2 : 1;

  const onFile = (e) => {
    const f = e.target.files && e.target.files[0];
    setMsg(null);
    if (!f) return setFile(null);
    if (!ID_FILE_TYPES.includes(f.type)) {
      setFile(null);
      return setMsg({ type: "error", text: "Please choose a PDF, JPG or PNG file." });
    }
    if (f.size > ID_FILE_LIMIT) {
      setFile(null);
      return setMsg({ type: "error", text: "The file is larger than 2 MB." });
    }
    setFile(f);
  };

  const submit = async (e) => {
    e.preventDefault();
    setMsg(null);
    if (name.trim().length < 2) return setMsg({ type: "error", text: "Enter your full name." });
    if (!file) return setMsg({ type: "error", text: "Attach an identity document (PDF, JPG or PNG)." });
    if (!dummyOk) return setMsg({ type: "error", text: "Please confirm you are using dummy data on this testnet prototype." });
    setSubmitting(true);
    const r = await submitKyc({ wallet: account, name: name.trim(), file });
    setSubmitting(false);
    if (r.ok) {
      setMsg({ type: "success", text: "Application submitted. A compliance officer will review it." });
      setName("");
      setFile(null);
      setDummyOk(false);
      loadStatus();
    } else if (r.unreachable) {
      setMsg({ type: "error", text: `${r.error} Start it with "cd backend && npm start" (expected at ${BACKEND_URL}), or ask compliance to whitelist your wallet directly.` });
    } else {
      setMsg({ type: "error", text: r.error });
    }
  };

  return (
    <div className="card">
      <div className="card-header">
        <div>
          <h3 className="card-title">{isKycVerified ? <ShieldCheck size={18} color="#10b981" /> : <UserCheck size={18} color="#3b82f6" />} KYC verification</h3>
          <p className="card-subtitle">
            {isKycVerified ? "Your wallet is whitelisted: you can invest, trade, claim and redeem." : "Only verified wallets can hold or trade the bond."}
          </p>
        </div>
        {isKycVerified ? <span className="badge badge-emerald">Verified</span> : remote.status === "rejected" ? <span className="badge badge-rose">Rejected</span> : <span className="badge badge-amber">Not verified</span>}
      </div>

      {/* Stepper */}
      <div style={{ display: "flex", alignItems: "center", gap: "0.5rem", margin: "0.25rem 0 1.25rem" }} aria-label="KYC progress">
        {STEPS.map((label, i) => {
          const n = i + 1;
          const done = current > n || (n === 3 && current === 3);
          const active = current === n;
          return (
            <React.Fragment key={label}>
              <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
                <span
                  style={{
                    width: 26, height: 26, borderRadius: "50%", display: "inline-flex", alignItems: "center", justifyContent: "center", fontSize: "0.75rem", fontWeight: 700,
                    background: done ? "var(--accent-emerald)" : active ? "var(--accent-blue)" : "var(--bg-input)",
                    color: done || active ? "#fff" : "var(--text-muted)",
                    border: "1px solid var(--border-active)",
                  }}
                >
                  {done ? "✓" : n}
                </span>
                <span style={{ fontSize: "0.78rem", color: active || done ? "var(--text-primary)" : "var(--text-muted)", fontWeight: 600 }}>{label}</span>
              </div>
              {i < STEPS.length - 1 && <div style={{ flex: 1, height: 1, background: "var(--border-active)", minWidth: 16 }} />}
            </React.Fragment>
          );
        })}
      </div>

      {!account && <p style={{ color: "var(--text-secondary)", fontSize: "0.85rem" }}>Connect your wallet to start verification.</p>}

      {account && !isKycVerified && remote.status === "pending" && (
        <p style={{ color: "var(--text-secondary)", fontSize: "0.85rem" }}>
          Your application is under review. This page updates automatically when compliance approves it.
        </p>
      )}

      {account && !isKycVerified && remote.status !== "pending" && (
        <form onSubmit={submit}>
          {remote.status === "rejected" && (
            <div className="alert-banner error"><span>Your previous application was rejected. You can submit a corrected one below.</span></div>
          )}
          <div className="grid-2">
            <div className="input-group">
              <label className="input-label" htmlFor="kycName">Full name</label>
              <input id="kycName" className="input-field" value={name} onChange={(e) => setName(e.target.value)} placeholder="As on your ID" maxLength={100} />
            </div>
            <div className="input-group">
              <label className="input-label" htmlFor="kycFile">Identity document (PDF / JPG / PNG, max 2 MB)</label>
              <input id="kycFile" className="input-field" type="file" accept=".pdf,.jpg,.jpeg,.png" onChange={onFile} />
              {file && <span style={{ fontSize: "0.75rem", color: "var(--text-muted)", display: "inline-flex", alignItems: "center", gap: "0.3rem", marginTop: "0.3rem" }}><FileText size={12} /> {file.name}</span>}
            </div>
          </div>
          <label style={{ display: "flex", gap: "0.5rem", alignItems: "center", fontSize: "0.8rem", color: "var(--text-secondary)", marginTop: "0.75rem" }}>
            <input type="checkbox" checked={dummyOk} onChange={(e) => setDummyOk(e.target.checked)} />
            This is a testnet prototype: I am uploading dummy data, not a real identity document.
          </label>
          {msg && <div className={`alert-banner ${msg.type}`} style={{ marginTop: "0.75rem", marginBottom: 0 }}><span>{msg.text}</span></div>}
          {remote.unreachable && !msg && <p style={{ color: "var(--accent-amber)", fontSize: "0.8rem", marginTop: "0.75rem" }}>The KYC service looks offline right now.</p>}
          <button type="submit" className="btn btn-primary" disabled={submitting} style={{ marginTop: "1rem", width: "100%" }}>
            {submitting ? "Submitting..." : "Submit KYC application"}
          </button>
        </form>
      )}
    </div>
  );
}
