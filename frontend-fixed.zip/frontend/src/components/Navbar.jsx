import React from "react";
import { ShieldCheck, ShieldAlert, Wallet, Globe, Copy, Check, LogOut } from "lucide-react";

const TABS = [
  ["investor", "Investor Portfolio"],
  ["marketplace", "Secondary Market"],
  ["admin", "Issuer & Compliance"],
  ["transparency", "Audit & Oracles"],
];

export default function Navbar({ account, network, networks, onSelectNetwork, connectWallet, disconnect, isKycVerified, chainOk, roles, activeTab, setActiveTab }) {
  const role = roles && roles.admin ? ["Admin", "badge-blue"] : roles && roles.compliance ? ["Compliance", "badge-emerald"] : roles && (roles.issuer || roles.distributorIssuer) ? ["Issuer", "badge-amber"] : roles && roles.loaded ? ["Investor", "badge"] : null;
  const [copied, setCopied] = React.useState(false);

  const copyAddress = async () => {
    if (!account) return;
    try {
      await navigator.clipboard.writeText(account);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (e) {
      console.warn("Clipboard unavailable:", e);
    }
  };

  return (
    <header className="nav-header">
      <div className="nav-wrapper">
        <div className="brand-section" onClick={() => setActiveTab("investor")}>
          <div className="brand-logo">B</div>
          <div>
            <div className="brand-title">AURA BONDS</div>
            <div className="brand-subtitle">Institutional RWA Debt Terminal</div>
          </div>
        </div>

        <nav className="nav-tabs" aria-label="Main">
          {TABS.map(([key, label]) => (
            <button key={key} onClick={() => setActiveTab(key)} className={`nav-tab-btn ${activeTab === key ? "active" : ""}`}>
              {label}
            </button>
          ))}
        </nav>

        <div className="nav-controls">
          <div className="select-network" title="Network used for reading and sending transactions">
            <Globe size={14} color="#3b82f6" />
            <select
              aria-label="Network"
              value={network}
              onChange={(e) => onSelectNetwork(e.target.value)}
              style={{ background: "transparent", border: "none", color: "inherit", fontSize: "inherit", fontWeight: "inherit", outline: "none", cursor: "pointer" }}
            >
              {Object.values(networks).map((n) => (
                <option key={n.key} value={n.key} style={{ background: "#151d2c" }}>
                  {n.label}
                </option>
              ))}
            </select>
          </div>

          {account && !chainOk && <div className="badge badge-amber" title="Wallet is on a different chain than the selected network">Wrong network</div>}

          {account && role && <span className={`badge ${role[1]}`} style={{ textTransform: "uppercase", fontSize: "0.68rem" }}>{role[0]}</span>}

          {account && (
            <div className={`badge ${isKycVerified ? "badge-emerald" : "badge-amber"}`}>
              {isKycVerified ? (
                <>
                  <ShieldCheck size={14} />
                  <span>KYC Verified</span>
                </>
              ) : (
                <>
                  <ShieldAlert size={14} />
                  <span>KYC Pending</span>
                </>
              )}
            </div>
          )}

          {account ? (
            <>
              <button onClick={copyAddress} className="btn btn-secondary btn-sm font-mono" title="Click to copy full address" style={{ gap: "0.4rem" }}>
                <span style={{ width: "6px", height: "6px", borderRadius: "50%", backgroundColor: chainOk ? "#10b981" : "#f59e0b", display: "inline-block" }}></span>
                <span>{account.slice(0, 6)}...{account.slice(-4)}</span>
                {copied ? <Check size={12} color="#10b981" /> : <Copy size={12} color="#94a3b8" />}
              </button>
              <button onClick={disconnect} className="btn-icon" title="Forget this account in the page" aria-label="Disconnect">
                <LogOut size={14} />
              </button>
            </>
          ) : (
            <button onClick={connectWallet} className="btn btn-primary btn-sm">
              <Wallet size={14} />
              <span>Connect Wallet</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
}
